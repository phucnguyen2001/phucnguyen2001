/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.xpoly.helper;

/**
 *
 * @author Dell
 */
public class Constant {

    public static final int SO_SACH_MUON_TOI_DA = 5;
    public static final int SO_NGAY_MUON_TOI_DA = 10;
    public static final int SO_LAN_GIA_HAN_TOI_DA = 2;
}
